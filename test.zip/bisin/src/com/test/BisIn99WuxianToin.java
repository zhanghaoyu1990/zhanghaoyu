package com.test;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.codec.digest.DigestUtils;

import com.paic.jrkj.tk.secret.digest.Digest;
import com.paic.jrkj.tk.secret.digest.RSADigest;
import com.paic.jrkj.tk.util.ByteUtil;
import com.paic.jrkj.tk.util.HexUtil;
import com.paic.jrkj.tk.util.KeyUtil;
import com.paic.jrkj.tk.util.StreamUtil;

public class BisIn99WuxianToin {
	

		private static final String PROPERTY_TYPE = "Content-Type";
		private static final String PROPERTY = "application/x-www-form-urlencoded";
		private Digest digest;
		private Digest digest2;
				
		public void init(){
			String r = "30820276020100300D06092A864886F70D0101010500048202603082025C020100028181009A4CAB1754401878FC4D1CF13264870938FE90524C7AC8F52FE0A1650F5251C4D373278494FDDD394A53FCB3DAFB080D8B799C79B6244EE8307065EEE992ACC0C0CD07FC35F05980422904A7A8441BB77939626E3946F955D8B484018243BA32BE54EA2559E6B9CA65B9B21FF0BD732612A11B6368D9D0E845A9A999B8B90D6D020301000102818044B679C694D54A50AE82A4ADE0B415D28C9808AB2DB5CC422C050BBA967D213ED6AF445CED80B400AC52048A0FAD94E37B4637E197B449936AE6D2EDF704437B8E071271B4B31DB0CB062C0365BEA9681706C909E804BAF52DC473173599F33B3A3FB11B005A13A8451F630F7AEFF53FFBC00714BD3C611BD95C7E075D2E0E81024100CCF2E1BB547FCB7352A588C8CE7143ACFDF4E4C9E4AFB470F4C5230CF594E61CAEB83F3CE67A594A2CF8F43A4EF2B9CD878BFB2DB7B00371646CA7416B37F3E1024100C0BBFF487542BEFABEE90A9D716597895BFD2F864501C4036B057C070AF777C1237D3C5A63EC566017D841C555BAB01563401DF75BAA495159C669CEBC470B0D02401E5CB91E54855E31A683C980DE3C9F670874785484A1971CC8D64FBC02C1DD5950751141476FC6BC9B6F0257850CA6841159A68B7E54001E935F196432AB266102404E0189002D9D97286B6E6CC26E6BFCDA366611FF191CEED5A7522FF1B5C9952991909585CC1D92940FF29224295F86F71115994B4D496DA5445D9EE372A69A5D02410086F8836296AEC97E5D0233E95C3A51680A17827E2969D8A6613E4B5F8FA5A2EEB925D565357250A1B33CEBD3D21EF77DB3BF0A99A15B03969389C5194EA7679D";
			digest = new RSADigest("BC", KeyUtil.readPrivateKey(HexUtil.decode(r)), null);
			String u = "30819F300D06092A864886F70D010101050003818D00308189028181009A3F6766BD12D06F1CC96705A784D749FEAFFAB70D7743730090FC15D0126E63164A644C3896B5F96BF8F91F7E12C9EBE58B7CAB3774BB6880AC3638F281295BCCF413CB973779E30EC0B985C2CD931EC33C616F423C1F451FEFF2D43726BFA152148F9F3F4DEB4AA343D8B949A75DDAED7F866E7614BF52A64D8370FAAC4E150203010001";
			digest2 = new RSADigest("BC", null, KeyUtil.readPublicKey(HexUtil.decode(u)));
		}
		
		public class MyTrustManager implements X509TrustManager{

			@Override
			public void checkClientTrusted(X509Certificate[] arg0, String arg1)
					throws CertificateException {
				
			}

			@Override
			public void checkServerTrusted(X509Certificate[] arg0, String arg1)
					throws CertificateException {
				// TODO Auto-generated method stub
				
			}

			@Override
			public X509Certificate[] getAcceptedIssuers() {
				return new X509Certificate[]{};
			}

		}
		
		private HttpsURLConnection getHttpsConn(String url){
			try {
				URL url1 = new URL(url);
				HttpsURLConnection conn = (HttpsURLConnection)url1.openConnection();
				SSLContext sc;
				sc = SSLContext.getInstance("SSL");
				sc.init(null, new TrustManager[]{new MyTrustManager()}, new SecureRandom());
				conn.setSSLSocketFactory(sc.getSocketFactory());
				return conn;
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			} catch (KeyManagementException e) {
				e.printStackTrace();
			} catch (IOException e){
				e.printStackTrace();
			}
			return null;
		}
		
		public String write(String dataStr,String url,String serviceId) throws Exception{
//					HttpsURLConnection conn = getHttpsConn(url);
					HttpURLConnection conn = (HttpURLConnection)(new URL(url).openConnection()) ;
					DataOutputStream out = null;
						conn.setConnectTimeout(120*1000);
						conn.setDoOutput(true);
						conn.setDoInput(true);
						conn.setRequestMethod("POST");
						conn.setUseCaches(false);
						conn.setRequestProperty(PROPERTY_TYPE, PROPERTY);
						
						conn.connect();
						String ret ="";
						byte data[] = dataStr.getBytes();
						out =  new DataOutputStream(conn.getOutputStream());
//�������Ҫbase64
//				        out.write(org.apache.commons.codec.binary.Base64.encodeBase64(data));
//�ڵ��ڣ�����base64						
						byte[] serviceId1 = serviceId.getBytes();
				        out.write(ByteUtil.join(serviceId1,data));
//���ϴ���	���ڵ��ڣ�����base64			        
						out.flush();
						out.close();
						System.out.println(conn.getResponseCode() + ">>" + conn.getResponseMessage());
						byte[] bytes= StreamUtil.toByteArray(conn.getInputStream());
						if(bytes == null || bytes.length == 0){
							System.out.println("time out");
						}else{
//							String ret = new String(org.apache.commons.codec.binary.Base64.decodeBase64(bytes), "utf-8");
							//��������base64
							ret = new String(bytes, "utf-8");
							//System.out.println("biz:"+ret);
							
							/*String resultData = XmlUtil.getNodeValue(ret, "bizdata", "data");
							
							System.out.println("resultData:"+resultData);*/
						}
						conn.disconnect();
						return ret;

				}
		
	

	/**
	 * @param args
	 * @throws Exception
	 */
	/**
	 * @param args
	 * @throws Exception
	 */
	/**
	 * @param args
	 * @throws Exception
	 */
	/**
	 * @param args
	 * @throws Exception
	 */
	/**
	 * @param args
	 * @throws Exception
	 */
	/**
	 * @param args
	 * @throws Exception
	 */
	/**
	 * @param args
	 * @throws Exception
	 */
	/**
	 * @param args
	 * @throws Exception
	 */
	/**
	 * @param args
	 * @throws Exception
	 */
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		
		String url="https://jk-bis-stg.dmzstg.pingan.com.cn:7443/bis/99WuXianCallback";
	    String orderId = "20150908121213014";
	    String orderTime = "20150908121213";
	    String ncOrderId = "";
	    String useTime = "20150908121213";
	    
	    
		String cardId = "200003";
		String merid="Z0061";
		String merpwd="wlt123456";
		String key="WLT123456YKKM";
		String version="1.0";
		String isnotify="1";
		String notifyurl="https://jk-bis-stg.dmzstg.pingan.com.cn:7443/bis/99WuXianCallback";

		Map<String,Object> paramap = new HashMap<String,Object>();
		paramap.put("retCode",1);//Ӧ�����
		paramap.put("errMsg","success");//������Ϣ
		paramap.put("merId",merid);//�̻�ID
		paramap.put("orderId",orderId);//�ͻ��˶�����ˮ��
		paramap.put("ncOrderId",ncOrderId);//
		paramap.put("cardId",cardId);
		paramap.put("num",1);
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		Map<String,Object> card = new HashMap<String,Object>();
		card.put("cardNo","");//����(����)
		card.put("cardPws","");//����(����)
		list.add(card);
		paramap.put("cards",list);
		paramap.put("status","��ʹ��");
		paramap.put("sinopecNo","32324234234");
		paramap.put("useTime","");
		paramap.put("useProvince","�Ϻ�");
		paramap.put("useDot","�Ϻ���");
		
		StringBuffer ssb = new StringBuffer();
		ssb.append(merid);
		ssb.append(cardId);
		ssb.append(1);
		ssb.append(orderId);
		ssb.append(orderTime);
		BisIn99WuxianToin sc = new BisIn99WuxianToin();
		String sign = sc.getSign(ssb.toString(), key);
//		sb.append("&sign="+sign);
//		
//		BisIn99WuxianToin a = new BisIn99WuxianToin();
//		System.out.println(a.write(sb.toString(),url,serviceId));

	}
	
	
	private String getSign(String srcSign,String key) {
		srcSign = srcSign + key;
		String sign = DigestUtils.sha1Hex(srcSign);
		return sign;
	}	



}
