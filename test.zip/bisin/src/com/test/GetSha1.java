package com.test;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Date;
import java.util.Formatter;

import com.alibaba.fastjson.JSONObject;

public class GetSha1 {

//	public static void main(String[] args) throws IOException {
	public static byte[] getsha1(String path) throws FileNotFoundException, ParseException{
		// TODO Auto-generated method stub
//		String serviceId = "4000010000000986";
//		System.out.println(serviceId.getBytes());
//		String path = "D:\\Users\\zhanghaoyu904\\Desktop\\接口文件\\4000010000001003.txt";
//		String serviceId = "4000010000001003";
		String filenameToSend = path;
//		String ret ="";
		String salt = "eB)<w!a!l?$7Mo!(qL^F2ns^L9]r]VmR";
		File f = new File(filenameToSend);
		byte data[] = new byte[(int) f.length()];
		FileInputStream fis = new FileInputStream(filenameToSend);
		try {
			fis.read(data);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fis.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String datastr = new String(data);
		JSONObject jsonObject = JSONObject.parseObject(datastr);
		String providerId = jsonObject.getString("providerId");
		String codeData = jsonObject.getString("codeData");
		String veritynum = jsonObject.getString("veritynum");
		String veritytime = dateToStamp(jsonObject.getString("veritytime"));
		String storename = jsonObject.getString("storename");
		String shopno = jsonObject.getString("shopno");
		String str = salt + providerId + codeData + veritynum + veritytime + storename +shopno;
		System.out.println(str);
//		System.out.println(encryptPassword(str));
		jsonObject.put("sign", encryptPassword(str));
		String str1 = jsonObject.toJSONString();
		System.out.println(str1);
		System.out.println(jsonObject.getString("sign"));
		byte[] data2 = str1.getBytes();
		return data2;
	}
	private static String encryptPassword(String password)
	{
	    String sha1 = "";
	    try
	    {
	        MessageDigest crypt = MessageDigest.getInstance("SHA-1");
	        crypt.reset();
	        crypt.update(password.getBytes("UTF-8"));
	        sha1 = byteToHex(crypt.digest());
	    }
	    catch(NoSuchAlgorithmException e)
	    {
	        e.printStackTrace();
	    }
	    catch(UnsupportedEncodingException e)
	    {
	        e.printStackTrace();
	    }
	    return sha1;
	}
	
	private static String byteToHex(final byte[] hash)
	{
	    Formatter formatter = new Formatter();
	    for (byte b : hash)
	    {
	        formatter.format("%02x", b);
	    }
	    String result = formatter.toString();
	    formatter.close();
	    return result;
	}
	
	/* 
     * 将时间转换为时间戳
     */    
    public static String dateToStamp(String s) throws ParseException{
        String res;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = simpleDateFormat.parse(s);
        long ts = date.getTime();
        res = String.valueOf(ts);
        return res;
    }
    
    public static void main(String[] args) throws FileNotFoundException, ParseException {
		String path = "D:\\Users\\zhanghaoyu904\\Desktop\\接口文件\\4000010000001003.txt";
		String serviceId = "4000010000001003";
    	getsha1(path);
	}

}
