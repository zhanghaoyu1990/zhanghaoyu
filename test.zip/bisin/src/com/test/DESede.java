package com.test;


import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

import com.paic.jrkj.tk.util.HexUtil;


public class DESede {

    private static final String Algorithm = "DESede"; // 定义 加密算法,可用 DES,DESede,Blowfish

    /**
     * 根据给定密钥进行加密
     * 
     * @param keybyte
     * @param src
     * @return
     */
    public static String encryptMode(String key, String src) throws UnsupportedEncodingException {

        return byte2Base64(encryptMode(getKeyByte(key), src.getBytes("UTF-8")));
    }

    // keybyte为加密密钥，长度为24字节
    // src为被加密的数据缓冲区（源）
    public static byte[] encryptMode(byte[] keybyte, byte[] src) {
        try {
            // 生成密钥
            SecretKey deskey = new SecretKeySpec(keybyte, Algorithm);

            // 加密
            Cipher c1 = Cipher.getInstance(Algorithm);
            c1.init(Cipher.ENCRYPT_MODE, deskey);
            return c1.doFinal(src);
        } catch (java.security.NoSuchAlgorithmException e1) {
            e1.printStackTrace();
        } catch (javax.crypto.NoSuchPaddingException e2) {
            e2.printStackTrace();
        } catch (java.lang.Exception e3) {
            e3.printStackTrace();
        }
        return null;
    }

    /**
     * 根据密钥解密
     * 
     * @param keybyte加密密钥，长度为24字节
     * @param src加密后的缓冲区
     * @return
     */
    public static String decryptMode(byte[] keybyte, String src) {

        return new String(decryptMode(keybyte, Base64.decodeBase64(src)));
    }

    /**
     * 根据密钥解密
     * 
     * @param keybyte加密密钥，长度为24字节
     * @param src加密后的缓冲区
     * @return
     */
    public static byte[] decryptMode(byte[] keybyte, byte[] src) {
        try {
            // 生成密钥
            SecretKey deskey = new SecretKeySpec(keybyte, Algorithm);

            // 解密
            Cipher c1 = Cipher.getInstance(Algorithm);
            c1.init(Cipher.DECRYPT_MODE, deskey);
            return c1.doFinal(src);
        } catch (java.security.NoSuchAlgorithmException e1) {
            e1.printStackTrace();
        } catch (javax.crypto.NoSuchPaddingException e2) {
            e2.printStackTrace();
        } catch (java.lang.Exception e3) {
            e3.printStackTrace();
        }
        return null;
    }

    /**
     * 密钥转换
     * 
     * @param key
     * @return
     * @throws UnsupportedEncodingException
     */
    public static byte[] getKeyByte(String key) {
        // 加密数据必须是24位，不足补0；超出24位则只取前面的24数据
        byte[] newdata = new byte[24];
        byte[] data;
        try {
            data = key.getBytes("UTF-8");
            int len = data.length;
            System.arraycopy(data, 0, newdata, 0, len > 24 ? 24 : len);
        } catch (UnsupportedEncodingException e) {
        	
        }
        return newdata;
    }

    /**
     * 转换成base64编码
     * 
     * @param b
     * @return
     */
    public static String byte2Base64(byte[] b) {
        return Base64.encodeBase64String(b);

    }

    /**
     * 转换成十六进制字符串
     * 
     * @param b
     * @return
     */
    public static String byte2hex(byte[] b) {
        String hs = "";
        String stmp = "";

        for (int n = 0; n < b.length; n++) {
            stmp = (java.lang.Integer.toHexString(b[n] & 0XFF));
            if (stmp.length() == 1)
                hs = hs + "0" + stmp;
            else
                hs = hs + stmp;
            if (n < b.length - 1)
                hs = hs + ":";
        }
        return hs.toUpperCase();
    }

    public static void main(String[] args) throws IOException {
        // 商户密钥
        // 85D3EB9DC40872FF0C037A46CEDDB330
        // 85D3EB9DC40872FF770E6ED091A941AD aaaaaa444444
        String key = "793445315DF40BEA";
//        byte[] keyBytes = getKeyByte(key);
        // 数据明文
        String szSrc = "aaaaaa444452s";
        // 1.密钥转换
        System.out.println("加密前的字符串:" + szSrc);
        // 2.根据给定密钥进行3DES加密
//        byte[] encoded = encryptMode(keyBytes, szSrc.getBytes());
//        String hex = HexUtil.byte2hex(encoded);
        byte[] bytes = desCrypto(szSrc.getBytes(), key);
        String hex1 = HexUtil.encode(bytes);
//
//        // 3.将3DES加密数据做Base64编码
//        String codeSrc = byte2Base64(encoded);
//        System.out.println("加密后的字符串:" + codeSrc);
        // 数据解密
        // 1.密文数据通过Base64解码
//        byte[] bb = Base64.decodeBase64("YIT2Zv8kwbceYzt8H/sxLQ==");
        // 2.根据密钥3DES解密
//        byte[] srcBytes = decryptMode(keyBytes, bb);
//        System.out.println("加密后的字符串:" + hex);
        System.out.println("加密后的字符串hex1:" + hex1);
    }


    public static byte[] desCrypto(byte[] datasource, String password) {
        try{
            SecureRandom random = new SecureRandom();
            DESKeySpec desKey = new DESKeySpec(HexUtil.decode(password));
            //创建一个密匙工厂，然后用它把DESKeySpec转换成
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
            SecretKey securekey = keyFactory.generateSecret(desKey);
            //Cipher对象实际完成加密操作
            Cipher cipher = Cipher.getInstance("DES");
            //用密匙初始化Cipher对象
            cipher.init(Cipher.ENCRYPT_MODE, securekey, random);
            //现在，获取数据并加密
            //正式执行加密操作
            return cipher.doFinal(datasource);
        }catch(Throwable e){
            e.printStackTrace();
        }
        return null;
    }

}