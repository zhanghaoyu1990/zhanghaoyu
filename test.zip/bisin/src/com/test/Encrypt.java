package com.test;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import org.apache.commons.codec.binary.Base64;


public class Encrypt {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
        //待加密内宄1�7
        String str = "2323";
        //密码，长度要昄1�7��1�7�数
        String password = "WLT123456789YKKM";
        byte[] result = Encrypt.desCrypto(str.getBytes(),password);
        System.out.println("DES加密后内容为＄1�7"+new String(result));
        

		// 加密
		byte[] b = Base64.encodeBase64(result, true);
		System.out.println("Base64加密后内容为＄1�7"+new String(b));
		System.out.println(encrypt(str,password));

		// 解密dJIi0sjSbS8=\r\n
		byte[] bb = Base64.decodeBase64("/FiNrWgbp9I=");
		System.out.println("Base64解密后内容为＄1�7"+new String(bb));

		//直接将如上内容解寄1�7
		try {
			byte[] decryResult = Encrypt.decrypt(bb, password);
			System.out.println("DES解密后内容为＄1�7"+new String(decryResult));
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
	
	public static String encrypt(String srcMsg, String key){
		//DES加密
		byte[] result = Encrypt.desCrypto(srcMsg.getBytes(), key);

		//Base64编码
		byte[] resultBase = Base64.encodeBase64(result, true);
		
		return new String(resultBase);
	}

	public static byte[] desCrypto(byte[] datasource, String password) {
		try {
			SecureRandom random = new SecureRandom();
			DESKeySpec desKey = new DESKeySpec(password.getBytes());
			// 创建丄1�7个密匙工厂，然后用它把DESKeySpec转换戄1�7
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
			SecretKey securekey = keyFactory.generateSecret(desKey);
			// Cipher对象实际完成加密操作
			Cipher cipher = Cipher.getInstance("DES");
			// 用密匙初始化Cipher对象
			cipher.init(Cipher.ENCRYPT_MODE, securekey, random);
			// 现在，获取数据并加密
			// 正式执行加密操作
			return cipher.doFinal(datasource);
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return null;
	}

	public static byte[] decrypt(byte[] src, String password) throws Exception {
		// DES算法要求有一个可信任的随机数溄1�7
		SecureRandom random = new SecureRandom();
		// 创建丄1�7个DESKeySpec对象
		DESKeySpec desKey = new DESKeySpec(password.getBytes());
		// 创建丄1�7个密匙工厄1�7
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
		// 将DESKeySpec对象转换成SecretKey对象
		SecretKey securekey = keyFactory.generateSecret(desKey);
		// Cipher对象实际完成解密操作
		Cipher cipher = Cipher.getInstance("DES");
		// 用密匙初始化Cipher对象
		cipher.init(Cipher.DECRYPT_MODE, securekey, random);
		// 真正弄1�7始解密操佄1�7
		return cipher.doFinal(src);
	}

}

