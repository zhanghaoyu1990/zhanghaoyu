package com.test;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;

import com.alibaba.fastjson.JSON;
import com.paic.jrkj.tk.net.http.HttpSSLClient;

/**
 * 99无限弄1�7放平叄1�7  -- 使用结果通知(sinopec/notify)
 * @author GENGQIAN499
 *
 */
public class TestSinopecUseCallbackAction {
	
	public static void main(String[] args) throws UnsupportedEncodingException {
		HttpSSLClient client = new HttpSSLClient("https://jk-bis-stg.dmzstg.pingan.com.cn:7443/bis/99WuXianCallback", 60000);
        client.setRequestMethod("POST");
        String merid="Z0061";
        String merpwd="wlt123456";
        String key="WLT123456YKKM";
        String cardId="200003";
        
        String orderId="2323";//
        String ncOrderId="2323";//vrKSRSdb8io=
        String cardNo="2323";
        String cardPws="2323";
        
        String useTime="20150918121214";
        try {
        	Map<String,Object> param = new HashMap<String,Object>();
        	param.put("retCode",1);//Ӧ�����
        	param.put("errMsg","success");//������Ϣ
        	param.put("merId",merid);//�̻�ID
        	param.put("orderId",orderId);//�ͻ��˶�����ˮ��
        	param.put("ncOrderId",ncOrderId);//
        	param.put("cardId",cardId);
        	param.put("num",1);
        	List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
        	Map<String,Object> card = new HashMap<String,Object>();
        	cardNo = new String(Base64.encodeBase64(Encrypt.desCrypto(cardNo.getBytes(),key), true));
        	cardPws = new String(Base64.encodeBase64(Encrypt.desCrypto(cardPws.getBytes(),key), true));
        	System.out.println(cardNo+"||"+cardPws);
        	card.put("cardNo",cardNo);//����(����)
        	card.put("cardPws",cardPws);//����(����)
//        	card.put("cardNo","vrKSRSdb8io=");//����(����)
//        	card.put("cardPws","vrKSRSdb8io=");//����(����)
        	list.add(card);
        	param.put("cards",list);
        	param.put("status","��ʹ��");
        	param.put("sinopecNo","234234234234");
        	param.put("useTime",useTime);
        	param.put("useProvince","�Ϻ�");
        	param.put("useDot","�Ϻ�����");
        	String json = JSON.toJSONString(param);
    		System.out.println(json);
    		byte[] data = json.getBytes("UTF-8");
            client.connect();
            client.send(data);
            byte[] ret = client.received();
            String result = new String(ret, "UTF-8");
            System.out.println(result);
        }catch (Exception e) {
        	e.printStackTrace();
        } finally {
            client.disconnect();
        }
	
	}



}
