package test;


public class XMLUtils {

	public static String getSignXMLString(String xmlString,String sign) {
		String StrVal = "";
		if (xmlString != null && !"".equals(xmlString)) {
			boolean isExistStr = xmlString.contains("<sign>");
			int a = xmlString.lastIndexOf("<value>");
			int b = xmlString.lastIndexOf("</value>");
			String requestXML = "";
			String requestXMLStr="";
			requestXML = xmlString.substring(0, b);
			requestXMLStr = xmlString.substring(b, xmlString.length());
			if (isExistStr) {
				StrVal = requestXML+sign+requestXMLStr;
			} else {
				StrVal = requestXML;
			}
		}
		return StrVal.trim();
	}
	 public static String getNodeValues(String xmlString, String... names)
	  {
	    if ((names == null) || (names.length == 0)) {
	      return null;
	    }
	    String nodeValue = xmlString;
	    for (String name : names) {
	      nodeValue = getNodeValue(nodeValue, name);
	      if (nodeValue == null) {
	        return null;
	      }
	    }
	    return nodeValue;
	  }
	 public static String getNodeValue(String xmlString, String name)
	  {
	    if (xmlString == null) {
	    
	      return null;
	    }
	    int startPos = xmlString.indexOf("<" + name + ">");
	    if (startPos == -1) {
	      
	      return null;
	    }
	    int endPos = xmlString.lastIndexOf("</" + name + ">");
	    if (endPos == -1) {
	      return null;
	    }
	    return xmlString.substring(startPos + ("</" + name + ">").length() - 1, endPos);
	  }
}