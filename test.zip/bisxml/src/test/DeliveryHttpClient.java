package test;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;


public class DeliveryHttpClient {


	public static final Charset CHARSET_ISO8859_1 = Charset.forName("iso8859_1");
	
	private static final String PROPERTY_TYPE = "Content-Type";
	private static final String PROPERTY = "application/x-www-form-urlencoded";
	
	public DeliveryHttpClient(){
	
	}

	private HttpsURLConnection getHttpsConn(){
		try {
			String urlPath = "https://jk-bis-stg.dmzstg.pingan.com.cn:7443/bis/service";
			
			URL url = new URL(urlPath);
			HttpsURLConnection conn = (HttpsURLConnection)url.openConnection();
			SSLContext sc;
			sc = SSLContext.getInstance("SSL");
			sc.init(null, new TrustManager[]{new MyTrustManager()}, new SecureRandom());
			conn.setSSLSocketFactory(sc.getSocketFactory());
			return conn;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (KeyManagementException e) {
			e.printStackTrace();
		} catch (IOException e){
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * write
	 */
	public void write(){
		
		HttpsURLConnection conn = getHttpsConn();
		DataOutputStream out = null;
		try {
			conn.setConnectTimeout(10*1000);
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			conn.setRequestProperty(PROPERTY_TYPE, PROPERTY);
			
			conn.connect();
			String filenameToSend = "commitOrder.xml";
//			String filenameToSend = "壹钱包查询当前用户券码列表接口.xml";
//			String filenameToSend = "壹钱包查询券码详情接口.xml";
			File f = new File(filenameToSend);
			byte data[] = new byte[(int) f.length()];
			FileInputStream fis = new FileInputStream(filenameToSend);
			fis.read(data);
			fis.close();
			String xmlStr=new String(data);
			String reqId=XMLUtils.getNodeValues(xmlStr, "bisdata", "reqId");
			String idx=XMLUtils.getNodeValues(xmlStr, "sign", "idx");
			String dataStr=XMLUtils.getNodeValues(xmlStr, "bizdata", "data");
			System.out.println(reqId);
			System.out.println(idx);
			System.out.println(dataStr);
			MessageDigest d = new MessageDigest();
			String sign = d.digest((dataStr+"abcdabcd").getBytes());
			String returnXml=XMLUtils.getSignXMLString(xmlStr,sign);
			System.out.println(returnXml);
			data=returnXml.getBytes();
			out =  new DataOutputStream(conn.getOutputStream());
	        out.write(org.apache.commons.codec.binary.Base64.encodeBase64(data));
			out.flush();
			out.close();
			System.out.println(conn.getResponseCode() + ">>" + conn.getResponseMessage());
			byte[] bytes= org.apache.commons.codec.binary.Base64.decodeBase64(toByteArray(conn.getInputStream()));
			if(bytes == null || bytes.length == 0){
				System.out.println("time out");
			}else{
				String ret = new String(bytes,"UTF-8");
				System.out.println("biz:"+ret);
				
			}
			conn.disconnect();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static byte[] toByteArray(InputStream is) throws IOException
	  {
	    ByteArrayOutputStream out = new ByteArrayOutputStream();
	    byte[] data = new byte[4096];
	    int len;
	    while ((len = is.read(data)) != -1) {
	      out.write(data, 0, len);
	      out.flush();
	    }
	    return out.toByteArray();
	  }


	public static void main(String[] args) {
		DeliveryHttpClient a = new DeliveryHttpClient();
		a.write();
	}
	
}
