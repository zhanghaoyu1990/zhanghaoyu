package test;

import java.security.NoSuchAlgorithmException;

public class BisUtil {
	
	 /**
	  * 
	  * @param key1   前密钥串 （可为空）
	  * @param data  报文data节点下的数据（不包括data节点）字符集Charset.forName("iso8859_1")
	  * @param key2 后密钥串 （可为空）
	  * @param type  加密类型 （md5还是sha-1）
	  * byte[] bytes1=dataStr.getBytes(Charset.forName("iso8859_1"));
		* byte[] key1 = "1qaz2wsx".getBytes();
		* byte[] key2 = "1234esxc".getBytes();
	  * @return 加密后的值
	  */
	  public static String getEncodeValue(byte[] key1,byte[] data,byte[] key2 ,String type)
	  {	    
	    java.security.MessageDigest digit;
	    String sign="";
		try {
			digit = java.security.MessageDigest.getInstance(type);
			digit.update(join(new byte[][] { key1, data, key2 }));
			byte[] sign2 =digit.digest();
			sign=encode(sign2);
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	    return sign;
	  }

	  public static String encode(byte[] src)
	  {
	    StringBuffer hs = new StringBuffer();
	
	    for (int i = 0; i < src.length; i++) {
	      String stmp = Integer.toHexString(src[i] & 0xFF).toUpperCase();
	      if (stmp.length() == 1)
	        hs.append("0").append(stmp);
	      else {
	        hs.append(stmp);
	      }
	    }
	    return hs.toString();
	  }
	  public static byte[] join(byte[][] byteArrs)
	  {
	    if (byteArrs == null) {
	      return null;
	    }
	    if (byteArrs.length == 0) {
	      return new byte[0];
	    }
	    int length = 0;
	    for (byte[] byteArr : byteArrs) {
	      if ((byteArr != null) && (byteArr.length != 0))
	        length += byteArr.length;
	    }
	    byte[] result = new byte[length];
	    int index = 0;
	    for (byte[] byteArr : byteArrs)
	      if ((byteArr != null) && (byteArr.length != 0)) {
	        System.arraycopy(byteArr, 0, result, index, byteArr.length);
	        index += byteArr.length;
	      }
	    return result;
	  }
}
