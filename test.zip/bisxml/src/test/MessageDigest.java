package test;


public class MessageDigest
{

  public MessageDigest()
  {

  }

  public String digest(byte[] bytes) throws SecurityException
  {
    try {
      java.security.MessageDigest digit = java.security.MessageDigest.getInstance("SHA-1");
      digit.update(bytes);
     
      byte[] sign = digit.digest();
      //String signData = encode(sign);
      String signData = HexUtil.byte2hex(sign);
      System.out.println("data1="+signData);
      return signData;
    } catch (Exception e) {
      throw new SecurityException("BUILD SIGNATURE FAIL", e);
    }
  }
  
  
 
}